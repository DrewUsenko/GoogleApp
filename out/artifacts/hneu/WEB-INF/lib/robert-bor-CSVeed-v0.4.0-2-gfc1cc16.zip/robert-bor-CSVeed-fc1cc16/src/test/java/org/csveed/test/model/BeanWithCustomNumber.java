package org.csveed.test.model;

public class BeanWithCustomNumber {

    private Double number;

    public Double getNumber() {
        return number;
    }

    public void setNumber(Double number) {
        this.number = number;
    }
}
