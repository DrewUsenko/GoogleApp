package org.csveed.test.model;

public class BeanWithoutGettersAndSetters {

    private String a;
    private String b;
    private String c;

}
