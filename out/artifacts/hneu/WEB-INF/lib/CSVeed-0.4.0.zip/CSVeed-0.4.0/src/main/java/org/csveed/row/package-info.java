/**
* The package responsible for converting a group of tokens into Header and Rows. In here you will find ways
* to read lines from the tokenizer and convert those either to a Header or a Row.
*/
package org.csveed.row;