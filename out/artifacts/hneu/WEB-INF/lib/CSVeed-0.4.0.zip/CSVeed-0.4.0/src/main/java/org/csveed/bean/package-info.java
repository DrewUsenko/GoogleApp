/**
* The package responsible for converting Rows to Beans. In here are the classes needed for reading class
* structures, configuring the mapping and executing the conversion from Row to Bean.
*/
package org.csveed.bean;